These are shortcut to existing .exe\[s] on your computer.



**Enjoy!**

